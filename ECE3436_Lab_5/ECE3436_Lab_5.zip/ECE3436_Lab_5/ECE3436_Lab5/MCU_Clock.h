//MCU_Clock.c (more info found on pg171 of the textbook)


//initilize MCU Clock at 80MHz
void PLL_Init(void);
